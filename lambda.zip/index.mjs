import { SendTemplatedEmailCommand } from "@aws-sdk/client-ses";
import { sesClient } from "./libs/sesClient.mjs";

/**
 * Replace this with the name of an existing template.
 */
const TEMPLATE_NAME = process.env.TEMPLATE_NAME;

/**
 * Replace these with existing verified emails.
 */
const MAIL_TO = process.env.MAIL_TO;
const MAIL_FROM = process.env.MAIL_FROM;
/**
 *
 * @param { {  name: string, mobile: string, email: string, requirement: string, product: string, purpose: string, quantity: string } } event
 * @param { string } templateName - The name of an existing template in Amazon SES.
 * @returns { SendTemplatedEmailCommand }
 */
const createReminderEmailCommand = (event, templateName) => {
  return new SendTemplatedEmailCommand({
    Destination: { ToAddresses: [MAIL_TO] },
    TemplateData: JSON.stringify({
      name: event.name ? event.name : "",
      email: event.email ? event.email : "",
      mobile: event.mobile ? event.mobile : "",
      requirement: event.requirement ? event.requirement : "",
      product: event.product ? event.product : "",
      purpose: event.purpose ? event.purpose : "",
      quantity: event.quantity ? event.quantity : "",
    }),
    Source: MAIL_FROM,
    Template: templateName,
  });
};

export const handler = async (event) => {
  console.log(JSON.stringify(event));
  const sendReminderEmailCommand = createReminderEmailCommand(
    event,
    TEMPLATE_NAME
  );
  try {
    return await sesClient.send(sendReminderEmailCommand);
  } catch (err) {
    console.log("Failed to send template email", err);
    return err;
  }
};
